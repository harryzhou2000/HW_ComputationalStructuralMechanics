nn=3;np=2; %numnode and num intpoint 
Ne = 10; %num elem 
h = 0.05; %height of beam
loadform = 2; L = 1;rho = 1e3*1;E = 1e9;nu = 0;G = E/(2*(nu+1));b = 0.1;nmode = 5;