nn=2;np=1; %numnode and num intpoint 
Ne = 10; %num elem 
h = 1; %height of beam
loadform = 2; L = 1;rho = 1e3*1;E = 1e9;nu = 0;G = E/(2*(nu+1));b = 0.1;nmode = 5;