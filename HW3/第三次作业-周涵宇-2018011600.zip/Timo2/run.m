CASEtimo_3r1_h1_L1;
TimoCalculate;